package test.cases.jira;

import org.junit.jupiter.api.Test;
import pages.jira.Story;


public class JiraTests extends BaseTest{

    @Test
    public void createAStory() {
        login();

        // API: Create a story in JIRA -> Follow the best practices in creating a story
        Story newStory = new Story(actions.getDriver());
        newStory.createStory("jira.projectKey", "jira.projectSummary", "jira.projectDescription");

        // API: Set priority based on the severity

        // API: Validate the story creation
    }
}
