package pages.jira;

import org.openqa.selenium.WebDriver;

import static com.telerikacademy.testframework.Utils.getConfigPropertyByKey;

public class LoginPage extends JiraHomePage{

    public LoginPage(WebDriver driver) {
        super(driver, "jira.loginPage");
    }

    public void loginUser(String userKey) {

        String username = getConfigPropertyByKey("jira.users." + userKey + ".username");
        String password = getConfigPropertyByKey("jira.users." + userKey + ".password");

        navigateToPage();
        assertPageNavigated();

        actions.waitForElementVisible("jira.loginPage.username");
        actions.typeValueInField(username, "jira.loginPage.username");
        actions.clickElement("jira.loginPage.continueButton");

        actions.waitForElementClickable("jira.loginPage.password");
        actions.typeValueInField(password, "jira.loginPage.password");

        actions.waitForElementVisible("jira.loginPage.loginButton");
        actions.clickElement("jira.loginPage.loginButton");

        actions.waitForElementVisible("jira.header.homeButton");
        actions.assertCorrectUrl("atlassian.startPage.url");
    }
}
