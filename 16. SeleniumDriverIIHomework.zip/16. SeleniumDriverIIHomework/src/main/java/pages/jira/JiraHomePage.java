package pages.jira;

import com.telerikacademy.testframework.pages.BasePage;
import org.openqa.selenium.WebDriver;

public abstract class JiraHomePage extends BasePage {
    public JiraHomePage(WebDriver driver, String pageUrlKey) {
        super(driver, pageUrlKey);
    }
}
