package pages.jira;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.openqa.selenium.WebDriver;

import static com.telerikacademy.testframework.Utils.getConfigPropertyByKey;

public class Story extends JiraHomePage {

    public Story(WebDriver driver) {
        super(driver, "jira.loginPage.projects");
    }

    public void createStory(String projectKey, String storySummary, String storyDescription) {

        //navigateToPage();
        //assertPageNavigated();
        actions.waitForElementVisible("jira.header.jiraSoftwareButton");
        actions.clickElement("jira.header.jiraSoftwareButton");

        String JIRA_API_URL = getConfigPropertyByKey("JIRA.API.URL");

        Response response = RestAssured
                .given()
                .contentType(ContentType.JSON)
                .body("{"
                        + "\"fields\": {"
                        + "  \"project\": {\"key\": \"" + projectKey + "\"},"
                        + "  \"summary\": \"" + storySummary + "\","
                        + "  \"description\": \"" + storyDescription + "\","
                        + "  \"issuetype\": {\"name\": \"Story\"}"
                        + "}"
                        + "}")
                .post(JIRA_API_URL);

        if (response.getStatusCode() == 201) {
            System.out.println("Story created successfully.");
        } else {
            System.err.println("Failed to create story. Status code: " + response.getStatusCode());
            System.err.println("Response body: " + response.getBody().asString());
        }
    }


}
