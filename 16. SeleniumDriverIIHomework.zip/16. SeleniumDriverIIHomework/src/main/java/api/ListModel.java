package api;

public class ListModel {
    public String id;
    public String name;
    public boolean closed;
    public String idBoard;
    public int pos;
    public Object status;
}
